
# app/models.py
from app import db
from flask_login import UserMixin
from datetime import datetime
from cryptography.fernet import Fernet

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), index=True, unique=True)
    email = db.Column(db.String(120), index=True, unique=True)
    encrypted_email = db.Column(db.String(200))  # Store the encrypted email
    password_hash = db.Column(db.String(128))
    account_balance = db.Column(db.Float, default=10000.0)  # Initial account balance

    transactions = db.relationship('Transaction', backref='user', lazy='dynamic')
    portfolio = db.relationship('Portfolio', backref='user', lazy='dynamic')

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    stock_symbol = db.Column(db.String(10))
    action = db.Column(db.String(10))  # 'buy' or 'sell'
    shares = db.Column(db.Integer)
    price = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)

class Portfolio(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    stock_symbol = db.Column(db.String(10))
    shares = db.Column(db.Integer)
    purchase_price = db.Column(db.Float)



class TransactionHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action = db.Column(db.String(10))  # 'buy' or 'sell'
    stock_symbol = db.Column(db.String(10))
    shares = db.Column(db.Integer)
    price = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, index=True, default=datetime.utcnow)



class NotificationPreference(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    enable_notifications = db.Column(db.Boolean, default=True)
    event_types = db.Column(db.String, nullable=True)  # Store selected event types (e.g., "order_execution,account_updates,price_alerts")
    notification_methods = db.Column(db.String, nullable=True)  # Store selected methods (e.g., "email,sms")
    notification_timing = db.Column(db.String, nullable=True)  # Store selected timing (e.g., "real-time,daily_summary")


class UserActivityLog(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))
    action = db.Column(db.String(255))  # Store the action description, e.g., "Logged in", "Made a trade"
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
