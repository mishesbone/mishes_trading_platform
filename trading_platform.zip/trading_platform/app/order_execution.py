# app/order_execution.py
from app.models import Order
from app.notifications import send_email_notification, send_sms_notification

def execute_order(order):
    # Code to execute the order and update user's portfolio

    # Notify the user about the order execution
    user_email = order.user.email  # Replace with actual user email retrieval
    user_phone_number = order.user.phone_number  # Replace with actual user phone retrieval
    subject = "Order Execution"
    message = f"Your order for {order.stock_symbol} has been executed."

    # Send email notification
    send_email_notification(user_email, subject, message)

    # Send SMS notification
    send_sms_notification(user_phone_number, message)
