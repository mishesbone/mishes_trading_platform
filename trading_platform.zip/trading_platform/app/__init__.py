# app/__init__.py
from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from app.config import DevelopmentConfig,Config  # Import the appropriate configuration class
from flask_admin import Admin
from flask_bcrypt import Bcrypt
from twilio.rest import Client


app = Flask(__name__)
bcrypt = Bcrypt(app)
admin = Admin(app, name='Admin Panel', template_mode='bootstrap3')
twilio_client = Client('your_account_sid', 'your_auth_token')



app.config.from_object(DevelopmentConfig)  # Configure the app for development (replace with the desired environment)
app.config['SESSION_COOKIE_SECURE'] = True

# Initialize database and migration
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Initialize login manager
login = LoginManager(app)
login.login_view = 'login'  # Define the login view function (e.g., 'login' route)

# Import and register your blueprints here (if you use blueprints)

from app import routes, models  # Import your routes and models

# If you're using blueprints, register them here

if __name__ == '__main__':
    app.run(debug=True)
