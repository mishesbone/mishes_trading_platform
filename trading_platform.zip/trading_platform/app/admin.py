#app/admin.py
from flask_admin.contrib.sqla import ModelView
from app.models import User

class UserAdmin(ModelView):
    column_list = ('id', 'username', 'email', 'account_balance')
    column_searchable_list = ('username', 'email')

admin.add_view(UserAdmin(User, db.session))
