# app/utils.py
import requests
from app.config import Config
from flask import url_for
from itsdangerous import * 
from app import app


def get_real_time_stock_data(symbol):
    base_url = "https://www.alphavantage.co/query"
    function = "TIME_SERIES_INTRADAY"
    interval = "1min"  # You can change the interval (e.g., "5min", "15min", "30min", "60min")
    api_key = Config.ALPHA_VANTAGE_API_KEY

    params = {
        "function": function,
        "symbol": symbol,
        "interval": interval,
        "apikey": api_key
    }

    response = requests.get(base_url, params=params)

    if response.status_code == 200:
        data = response.json()
        return data.get('Time Series (1min)')
    else:
        return None


def get_historical_stock_data(symbol, start_date, end_date):
    base_url = "https://www.alphavantage.co/query"
    function = "TIME_SERIES_DAILY_ADJUSTED"
    api_key = ALPHA_VANTAGE_API_KEY

    params = {
        "function": function,
        "symbol": symbol,
        "outputsize": "full",
        "apikey": api_key
    }

    response = requests.get(base_url, params=params)

    if response.status_code == 200:
        data = response.json()
        return data.get('Time Series (Daily)')
    else:
        return None


from cryptography.fernet import Fernet

# Generate a secret key (keep this key secure, it's used for encryption and decryption)
key = Fernet.generate_key()
cipher_suite = Fernet(key)

def encrypt_email(email):
    """
    Encrypt an email address.
    """
    encrypted_email = cipher_suite.encrypt(email.encode())
    return encrypted_email

def decrypt_email(encrypted_email):
    """
    Decrypt an encrypted email address.
    """
    decrypted_email = cipher_suite.decrypt(encrypted_email).decode()
    return decrypted_email



def send_password_reset_email(user):
    s = itsdangerous.TimedJSONWebSignatureSerializer(app.config['SECRET_KEY'], expires_in=1800)  # 1800 seconds = 30 minutes
    token = s.dumps({'user_id': user.id}).decode('utf-8')

    # Construct the reset password link including the token
    reset_password_url = url_for('reset_password', token=token, _external=True)

    # Send the reset password link to the user's email
    # Use your email service to send the email with the link
    mail.send_message('Reset Your Password',
                       sender='mishesbone@roboteknologies,org',
                       recipients=[user.email],
                       body=f'''To reset your password, visit the following link:
     {reset_password_url}
     If you didn't request this, simply ignore this email.'''
                       )
