import os

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your_secret_key'
    DEBUG = False

    # API config
    FXCM_API_KEY = 'your_fxcm_api_key'
    FXCM_API_URL = 'https://api.fxcm.com'

    ALPHA_VANTAGE_API_KEY = 'your_alpha_vantage_api_key'

    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'postgresql://username:password@localhost/dbname'
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    PERMANENT_SESSION_LIFETIME = 2592000

    WTF_CSRF_SECRET_KEY = 'a_secret_csrf_key'

    STRIPE_SECRET_KEY = 'your_stripe_secret_key'

    MAIL_SERVER = 'smtp.example.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = 'your_username'
    MAIL_PASSWORD = 'your_password'
    MAIL_DEFAULT_SENDER = 'your_email@example.com'

    ADMINS = ['admin@example.com']

    DEFAULT_ERROR_MESSAGE = "Something went wrong. Please try again later."
    DEFAULT_ERROR_TITLE = "Error"

    LOG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), 'logs')

    ITEMS_PER_PAGE = 10

    WTF_CSRF_TIME_LIMIT = 3600

class DevelopmentConfig(Config):
    DEBUG = True
    SQLALCHEMY_DATABASE_URI = 'postgresql://username:password@localhost/dev_dbname'
    MAIL_SERVER = 'smtp.dev-example.com'

class ProductionConfig(Config):
    SQLALCHEMY_DATABASE_URI = 'postgresql://username:password@localhost/prod_dbname'
    MAIL_SERVER = 'smtp.prod-example.com'

class TestingConfig(Config):
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory'
    WTF_CSRF_ENABLED = False
