# app/routes.py
from app.forms import LoginForm, RegistrationForm
from app.models import User, Portfolio
from flask import render_template, redirect, url_for,jsonify,request, flash
from flask_login import login_user, current_user, logout_user, login_required
import requests
from app import app, db, bcrypt
from app.config import Config 
from app.models import NotificationPreference
from app.models import UserActivityLog
from app.config import DevelopmentConfig,Config 
from app.utils import encrypt_email, decrypt_email
from flask import render_template, flash, redirect, url_for, request
from app import app
from app.forms import ForgotPasswordForm,ResetPasswordForm
from app.models import User
from app.utils import send_password_reset_email  
from app.models import User  


FXCM_API_KEY=Config.FXCM_API_KEY
FXCM_API_URL=Config.FXCM_API_URL
@app.route('/')
def index():
    # Your logic to render the landing page content
    return render_template('index.html')


@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))


@app.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user = User(username=form.username.data, email=form.email.data, password=hashed_password)
        db.session.add(user)
        db.session.commit()
        flash('Your account has been created!', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=form, real='real')

@app.route('/login', methods=['GET', 'POST'])
def demo_trade_login():
    if current_user.is_authenticated:
        return redirect(url_for('demo_dashboard'))  # Redirect authenticated users

    form = LoginForm()

    try:
        if form.validate_on_submit():
            if form.email.data and form.password.data:
                user = User.query.filter_by(email=form.email.data).first()

                if user and bcrypt.check_password_hash(user.password, form.password.data):
                    login_user(user, remember=form.remember.data)
                    next_page = request.args.get('next')
                    flash('Login successful!', 'success')
                    return redirect(next_page or url_for('demo_dashboard'))  # Redirect to the next page or home after successful login
                else:
                    flash('Login unsuccessful. Please check email and password.', 'danger')
            else:
                flash('Please provide both email and password.', 'danger')
    except Exception as e:
        flash('An error occurred while logging in.', 'danger')
        # Log the exception or handle it according to your requirements

    return render_template('login.html', title='Login', form=form)


@app.route('/real_trade_login', methods=['GET', 'POST'])
def real_trade_login():
    if current_user.is_authenticated:
        return redirect(url_for('real_dashboard'))  # Redirect authenticated users

    form = LoginForm()

    try:
        if form.validate_on_submit():
            if form.email.data and form.password.data:
                user = User.query.filter_by(email=form.email.data).first()

                if user and bcrypt.check_password_hash(user.password, form.password.data):
                    login_user(user, remember=form.remember.data)
                    next_page = request.args.get('next')
                    flash('Login successful!', 'success')
                    return redirect(next_page or url_for('real_dashboard'))  # Redirect to the next page or home after successful login
                else:
                    flash('Login unsuccessful. Please check email and password.', 'danger')
            else:
                flash('Please provide both email and password.', 'danger')
    except Exception as e:
        flash('An error occurred while logging in.', 'danger')
        # Log the exception or handle it according to your requirements

    return render_template('login.html', title='Login', form=form)



@app.route('/exchange_rates', methods=['GET'])
def exchange_rates():
    pair = request.args.get('pair', default='EUR/USD')  # Default currency pair
    headers = {
        'User-Agent': 'Your App',
        'Authorization': f'Bearer {FXCM_API_KEY}'
    }
    
    response = requests.get(f"{FXCM_API_URL}/v1/prices/{pair}", headers=headers)

    if response.status_code == 200:
        data = response.json()
        bid = data['prices'][0]['bids'][0]['price']
        ask = data['prices'][0]['asks'][0]['price']
        return jsonify({'pair': pair, 'bid': bid, 'ask': ask})
    else:
        return jsonify({'error': 'Unable to retrieve exchange rates'}), 500

@app.route('/show-exchange-rates', methods=['GET'])
def show_exchange_rates():
    return render_template('exchange_rates.html')


from app.utils import get_real_time_stock_data

@app.route('/real-time-data/<symbol>')
def real_time_data(symbol):
    data = get_real_time_stock_data(symbol)
    if data:
        # Process and render the data
        return render_template('real_time_data.html', data=data, symbol=symbol)
    else:
        flash('Failed to retrieve real-time data', 'error')
        return redirect(url_for('home'))

@app.route('/historical-data/<symbol>')
def historical_data(symbol):
    data = get_historical_stock_data(symbol)
    if data:
        # Process and render the data
        return render_template('historical_data.html', data=data, symbol=symbol)
    else:
        flash('Failed to retrieve historical data', 'error')
        return redirect(url_for('home'))


from app import app
from app.forms import BuyStockForm, SellStockForm

@app.route('/buy', methods=['GET', 'POST'])
def buy_stock():
    form = BuyStockForm()
    if form.validate_on_submit():
        # Process the purchase order, interact with the trading API
        # Update user's portfolio and transaction history
        flash('Stock purchase successful.', 'success')
        return redirect(url_for('portfolio'))
    return render_template('buy.html', form=form)

@app.route('/sell', methods=['GET', 'POST'])
def sell_stock():
    form = SellStockForm()
    if form.validate_on_submit():
        # Process the sell order, interact with the trading API
        # Update user's portfolio and transaction history
        flash('Stock sale successful.', 'success')
        return redirect(url_for('portfolio'))
    return render_template('sell.html', form=form)

@app.route('/portfolio')
def portfolio():
    # Retrieve user's portfolio data from your database
    return render_template('portfolio.html', portfolio_data=portfolio_data)

@app.route('/transactions')
def transactions():
    # Retrieve user's transaction history data from your database
    return render_template('transactions.html', transaction_data=transaction_data)


@app.route('/stock-chart')
def stock_chart():
    # Fetch historical stock data from Alpha Vantage or another data source
    # Calculate technical indicators (e.g., moving averages, RSI)
    # Use Plotly to create interactive stock charts
    # Return the HTML template with the chart
    return render_template('stock_chart.html')

@app.route('/financial-data/<symbol>')
def financial_data(symbol):
    # Fetch financial data for the specified stock symbol
    # Display relevant financial information in your template
    return render_template('financial_data.html')


@app.route('/stock-news/<symbol>')
def stock_news(symbol):
    # Fetch news articles related to the specified stock symbol
    # Display news articles in your template
    return render_template('stock_news.html')

@app.route('/create-alert', methods=['POST'])
def create_alert():
    symbol = request.form.get('symbol')
    threshold_price = request.form.get('threshold_price')
    # Store the alert in your database
    # Set up a mechanism to periodically check stock prices
    # Send notifications when the price crosses the threshold
    flash('Alert created successfully.', 'success')
    return redirect(url_for('dashboard'))





@app.route('/account/notification_preferences', methods=['GET'])
@login_required
def notification_preferences_settings():
    # Retrieve the user's notification preferences from the database
    user_notification_preferences = get_user_notification_preferences()  # Implement this function to fetch preferences
    return render_template('notification_preferences_settings.html', preferences=user_notification_preferences)

@app.route('/account/update_notification_preferences', methods=['POST'])
@login_required
def update_notification_preferences():
    # Retrieve and process the submitted form data
    # Update the user's notification preferences in the database
    # Flash a success message
    return redirect(url_for('notification_preferences_settings'))


# 
@app.route('/some_action', methods=['GET'])
@login_required
def some_action():
    # Perform the action
    
    # Create a user activity log entry
    log_entry = UserActivityLog(user=current_user, action="Performed some action")
    db.session.add(log_entry)
    db.session.commit()
    
    # Other actions and responses
    flash('Action completed and logged!', 'success')
    return redirect(url_for('some_other_route'))



@app.route('/reset_password/<token>', methods=['GET', 'POST'])
def reset_password(token):
    user = User.verify_reset_password_token(token)
    if not user:
        flash('The reset password link is invalid or expired.', 'danger')
        return redirect(url_for('login'))
    form = ResetPasswordForm()
    if form.validate_on_submit():
        hashed_password = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        user.password = hashed_password
        db.session.commit()
        flash('Your password has been updated!', 'success')
        return redirect(url_for('login'))
    return render_template('reset_password.html', title='Reset Password', form=form)


@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    form = ForgotPasswordForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user:
            send_password_reset_email(user)
            flash('An email with instructions to reset your password has been sent.', 'info')
            return redirect(url_for('login'))
        else:
            flash('This email is not registered. Please sign up.', 'danger')
            return redirect(url_for('register'))
    return render_template('forgot_password.html', title='Forgot Password', form=form)



@app.route('/trading_charts', methods=['GET'])
def trading_charts():
    # Example data preparation; Replace this with your data
    # Assuming 'chart_data' holds your market data
    chart_data = {
        'dates': ['2023-10-01', '2023-10-02', '2023-10-03'],
        'prices': [100, 120, 90]
    }
    
    return render_template('index.html', chart_data=chart_data)

from flask import render_template

@app.route('/settings', methods=['GET'])
@login_required
def settings():
    # Logic to fetch user settings data from your application's backend
    # For example:
    user_settings = {
    'name': 'John Doe',
    'email': 'john@example.com',
    'theme': 'dark',
    'notifications': {
        'email': True,
        'push': False,
    },
    'account_details': {
        'billing_address': '123 Main St, City, Country',
        'payment_method': 'Credit Card',
    }
    # Additional user settings...
}


    # Pass the user settings to the settings.html template
    return render_template('settings.html', user_settings=user_settings)

@app.route('/profile', methods=['GET'])
@login_required
def profile():
    # Fetch user information from the current user instance or your database
    user_info = {
        'username': current_user.username,  
        'email': current_user.email, 
        
    }

    # Render the user profile using the fetched information
    return render_template('profile.html', user_info=user_info)


@app.route('/update_settings', methods=['POST'])
@login_required
def update_settings():
    if request.method == 'POST':
        theme = request.form.get('theme')
        notifications = request.form.get('notifications')
        language = request.form.get('language')

        if theme and notifications and language:
            # Update the user's settings if all data is present
            user = User.query.get(current_user.id)
            if user:
                user.theme = theme
                user.notifications = notifications
                user.language = language
                db.session.commit()
                flash('Settings updated successfully!', 'success')
            else:
                flash('User not found.', 'danger')
        else:
            flash('Failed to update settings. Please provide all data.', 'danger')

        return redirect(url_for('settings'))  # Redirect to the settings page
