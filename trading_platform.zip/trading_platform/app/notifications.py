from flask_mail import Message
from twilio.rest import Client


def send_email(subject, recipients, text_body, html_body):
    msg = Message(subject, recipients=recipients)
    msg.body = text_body
    msg.html = html_body
    mail.send(msg)


def send_sms(recipient, message):
    twilio_client.messages.create(
        to=recipient,
        from_="your_twilio_phone_number",
        body=message
    )
